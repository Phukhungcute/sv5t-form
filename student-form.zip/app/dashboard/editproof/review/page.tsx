"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import jsPDF from "jspdf";
import { supabase } from "@/lib/supabase";
import { initializeStudentPage } from "@/lib/initializeStudentPage";

type ProofItem = {
  id: string;
  image: string;
  fileName: string;
  description: string;
};

type CategoryKey =
  | "ethics"
  | "study"
  | "physical"
  | "volunteer"
  | "integration"
  | "priority";

type ProofData = Record<
  CategoryKey,
  ProofItem[]
>;

type Student = {
  mssv: string;
  full_name: string;
};

const categories: {
  key: CategoryKey;
  title: string;
}[] = [
  {
    key: "ethics",
    title: "1. Đạo đức tốt",
  },
  {
    key: "study",
    title: "2. Học tập tốt",
  },
  {
    key: "physical",
    title: "3. Thể lực tốt",
  },
  {
    key: "volunteer",
    title: "4. Tình nguyện tốt",
  },
  {
    key: "integration",
    title: "5. Hội nhập tốt",
  },
  {
    key: "priority",
    title: "6. Tiêu chuẩn ưu tiên",
  },
];

const emptyProofData: ProofData = {
  ethics: [],
  study: [],
  physical: [],
  volunteer: [],
  integration: [],
  priority: [],
};

/*
  KEY RIÊNG CHO EDIT PROOF REVIEW
*/
const EDIT_REVIEW_PREFIX =
  "sv5t_editproof_review_";

const DB_NAME =
  "sv5t-editproof-db";

const STORE_NAME =
  "drafts";

/* =========================================================
   INDEXED DB
========================================================= */

function openEditProofDB(): Promise<IDBDatabase> {
  return new Promise(
    (resolve, reject) => {
      const request =
        indexedDB.open(
          DB_NAME,
          1
        );

      request.onupgradeneeded =
        () => {
          const db =
            request.result;

          if (
            !db.objectStoreNames.contains(
              STORE_NAME
            )
          ) {
            db.createObjectStore(
              STORE_NAME
            );
          }
        };

      request.onsuccess =
        () =>
          resolve(
            request.result
          );

      request.onerror =
        () =>
          reject(
            request.error
          );
    }
  );
}

async function loadEditProofData(
  key: string
): Promise<ProofData | null> {
  const db =
    await openEditProofDB();

  return new Promise(
    (resolve, reject) => {
      const transaction =
        db.transaction(
          STORE_NAME,
          "readonly"
        );

      const request =
        transaction
          .objectStore(
            STORE_NAME
          )
          .get(key);

      request.onsuccess =
        () => {
          db.close();

          resolve(
            request.result ??
              null
          );
        };

      request.onerror =
        () => {
          db.close();

          reject(
            request.error
          );
        };
    }
  );
}

async function deleteEditProofData(
  key: string
) {
  const db =
    await openEditProofDB();

  return new Promise<void>(
    (resolve, reject) => {
      const transaction =
        db.transaction(
          STORE_NAME,
          "readwrite"
        );

      transaction
        .objectStore(
          STORE_NAME
        )
        .delete(key);

      transaction.oncomplete =
        () => {
          db.close();
          resolve();
        };

      transaction.onerror =
        () => {
          db.close();
          reject(
            transaction.error
          );
        };
    }
  );
}

/* =========================================================
   IMAGE LOADER
========================================================= */

function loadImage(
  src: string
): Promise<HTMLImageElement> {
  return new Promise(
    (resolve, reject) => {
      const image =
        new Image();

      image.onload =
        () => resolve(image);

      image.onerror =
        () =>
          reject(
            new Error(
              "Không thể tải hình ảnh"
            )
          );

      image.src = src;
    }
  );
}

/* =========================================================
   PAGE
========================================================= */

export default function EditProofReviewPage() {
  const router = useRouter();

  const [student, setStudent] =
    useState<Student | null>(
      null
    );

  const [proofData, setProofData] =
    useState<ProofData>(
      emptyProofData
    );

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);

  /* =======================================================
     INITIALIZE
  ======================================================= */

  useEffect(() => {
  initializeStudentPage(router, "addition");
}, [router]);

  useEffect(() => {
  async function loadData() {
    try {
      // =================================================
      // 1. CHECK USER
      // =================================================

      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError || !user) {
        router.push("/");
        return;
      }

      // =================================================
      // 2. CHECK PROFILE
      // =================================================

      const {
        data: profile,
        error: profileError,
      } = await supabase
        .from("profiles")
        .select("mssv, role")
        .eq("id", user.id)
        .single();

      if (profileError || !profile) {
        console.error(
          "PROFILE ERROR:",
          profileError
        );

        router.push("/");
        return;
      }

      if (profile.role !== "student") {
        router.push("/admin");
        return;
      }

      // =================================================
      // 3. LOAD STUDENT
      // =================================================

      const {
        data: studentData,
        error: studentError,
      } = await supabase
        .from("students")
        .select(
          "mssv, full_name, class_name"
        )
        .eq("mssv", profile.mssv)
        .single();

      if (studentError || !studentData) {
        console.error(
          "STUDENT ERROR:",
          studentError
        );
        return;
      }

      setStudent(studentData);

      // =================================================
      // 4. LOAD EDIT REVIEW DATA
      // =================================================

      const key =
        `${EDIT_REVIEW_PREFIX}${studentData.mssv}`;

      console.log(
        "EDIT PROOF REVIEW KEY:",
        key
      );

      /*
        1. Kiểm tra localStorage
      */

      const local =
        localStorage.getItem(key);

      console.log(
        "EDIT PROOF LOCALSTORAGE:",
        local
      );

      if (local) {
        try {
          const parsed =
            JSON.parse(local);

          console.log(
            "EDIT PROOF REVIEW DATA FROM LOCAL:",
            parsed
          );

          setProofData(parsed);
          return;
        } catch (error) {
          console.error(
            "EDIT PROOF LOCALSTORAGE PARSE ERROR:",
            error
          );
        }
      }

      /*
        2. Kiểm tra IndexedDB
      */

      console.log(
        "EDIT PROOF: Đang tìm trong IndexedDB..."
      );

      const saved =
        await loadEditProofData(key);

      console.log(
        "EDIT PROOF INDEXEDDB DATA:",
        saved
      );

      if (saved) {
        setProofData(saved);

        console.log(
          "EDIT PROOF REVIEW LOAD SUCCESS"
        );
      } else {
        console.warn(
          "EDIT PROOF REVIEW: KHÔNG TÌM THẤY DATA → QUAY VỀ EDITPROOF"
        );

        router.push(
          "/dashboard/editproof"
        );
      }

    } catch (error) {
      console.error(
        "EDIT PROOF REVIEW LOAD ERROR:",
        error
      );
    } finally {
      setLoading(false);
    }
  }

  loadData();
}, [router]);

  /* =======================================================
     CREATE PDF
======================================================= */

  async function createPDF() {
    const pdf =
      new jsPDF({
        orientation:
          "portrait",
        unit: "mm",
        format: "a4",
      });

    let y = 20;

    pdf.setFontSize(18);
    pdf.setFont("helvetica", "bold");

    pdf.text(
      "HỒ SƠ BỔ SUNG MINH CHỨNG",
      105,
      y,
      {
        align: "center",
      }
    );

    y += 15;

    pdf.setFontSize(11);
    pdf.setFont(
      "helvetica",
      "normal"
    );

    pdf.text(
      `MSSV: ${student?.mssv ?? ""}`,
      15,
      y
    );

    y += 6;

    pdf.text(
      `Họ tên: ${
        student?.full_name ?? ""
      }`,
      15,
      y
    );

    y += 12;

    for (
      const category of categories
    ) {
      const items =
        proofData[
          category.key
        ];

      if (
        items.length === 0
      ) {
        continue;
      }

      if (y > 260) {
        pdf.addPage();
        y = 20;
      }

      pdf.setFontSize(14);
      pdf.setFont(
        "helvetica",
        "bold"
      );

      pdf.text(
        category.title,
        15,
        y
      );

      y += 10;

      for (
        let index = 0;
        index <
        items.length;
        index++
      ) {
        const item =
          items[index];

        if (
          y > 250
        ) {
          pdf.addPage();
          y = 20;
        }

        pdf.setFontSize(
          11
        );

        pdf.setFont(
          "helvetica",
          "bold"
        );

        pdf.text(
          `Minh chứng ${
            index + 1
          }`,
          15,
          y
        );

        y += 7;

        if (
          item.image
        ) {
          const image =
            await loadImage(
              item.image
            );

          const maxWidth =
            170;

          const maxHeight =
            100;

          const ratio =
            Math.min(
              maxWidth /
                image.width,
              maxHeight /
                image.height
            );

          const width =
            image.width *
            ratio;

          const height =
            image.height *
            ratio;

          if (
            y + height >
            285
          ) {
            pdf.addPage();
            y = 20;
          }

          pdf.addImage(
            item.image,
            "JPEG",
            20,
            y,
            width,
            height,
            undefined,
            "MEDIUM"
          );

          y +=
            height +
            7;
        }

        if (
          item.description
        ) {
          pdf.setFont(
            "helvetica",
            "normal"
          );

          pdf.setFontSize(
            10
          );

          const lines =
            pdf.splitTextToSize(
              `Mô tả: ${item.description}`,
              170
            );

          if (
            y +
              lines.length *
                5 >
            285
          ) {
            pdf.addPage();
            y = 20;
          }

          pdf.text(
            lines,
            15,
            y
          );

          y +=
            lines.length *
              5 +
            8;
        } else {
          y += 5;
        }
      }
    }

    return pdf;
  }

  /* =======================================================
     CONFIRM
======================================================= */

  async function confirmEdit() {
    if (
      !student?.mssv
    ) {
      return;
    }

    setSaving(true);

    try {
      /*
        -----------------------------------------------------
        1. LẤY BẢN PROOF GỐC MỚI NHẤT
        -----------------------------------------------------
      */

      const {
        data: latestProof,
        error: latestError,
      } =
        await supabase
          .from("proofs")
          .select(
            "version, file_path"
          )
          .eq(
            "mssv",
            student.mssv
          )
          .order(
            "version",
            {
              ascending:
                false,
            }
          )
          .limit(1)
          .single();

      if (
        latestError ||
        !latestProof
      ) {
        console.error(
          "LATEST PROOF ERROR:",
          latestError
        );

        alert(
          "Không tìm thấy hồ sơ minh chứng gốc."
        );

        return;
      }

      const baseVersion =
        latestProof.version;

      const newVersion =
        baseVersion + 1;

      /*
        -----------------------------------------------------
        2. BẢO VỆ FILE GỐC
        -----------------------------------------------------

        Copy file PDF hiện tại sang một path riêng.
        File gốc trong proofs KHÔNG bị xoá.
      */

      const originalPath =
        latestProof.file_path;

      const extension =
        originalPath
          .split(".")
          .pop() ??
        "pdf";

      const protectedPath =
      originalPath.replace(
        /\.pdf$/i,
        `_v${baseVersion}.pdf`
      );

      const {
        error: copyError,
      } =
        await supabase.storage
          .from("proofs")
          .copy(
            originalPath,
            protectedPath
          );

      /*
        Nếu file bảo vệ đã tồn tại
        thì không cần copy lại.
      */

      if (
        copyError &&
        !copyError.message
          ?.toLowerCase()
          .includes(
            "already exists"
          )
      ) {
        console.error(
          "PROTECT ORIGINAL ERROR:",
          copyError
        );

        alert(
          "Không thể bảo vệ file minh chứng gốc."
        );

        return;
      }

      /*
        -----------------------------------------------------
        3. TẠO PDF EDIT
        -----------------------------------------------------
      */

      const pdf =
        await createPDF();

      const pdfBlob =
        pdf.output(
          "blob"
        );

      /*
        -----------------------------------------------------
        4. FILE PATH MỚI
        -----------------------------------------------------
      */

      const newFilePath =
        `${student.mssv}/v${newVersion}*.pdf`;

      /*
        -----------------------------------------------------
        5. UPLOAD PDF EDIT
        -----------------------------------------------------
      */

      const {
        error: uploadError,
      } =
        await supabase.storage
          .from("proofs")
          .upload(
            newFilePath,
            pdfBlob,
            {
              contentType:
                "application/pdf",
              upsert: false,
            }
          );

      if (
        uploadError
      ) {
        console.error(
          "EDIT PROOF UPLOAD ERROR:",
          uploadError
        );

        alert(
          "Không thể tải PDF lên hệ thống."
        );

        return;
      }

      /*
        -----------------------------------------------------
        6. GHI DB edit_proofs
        -----------------------------------------------------
      */

      const {
        error: insertError,
      } =
        await supabase
          .from(
            "edit_proofs"
          )
          .insert({
            mssv:
              student.mssv,
            version:
              newVersion,
            base_version:
              baseVersion,
            file_path:
              newFilePath,
            status:
              "submitted",
          });

      if (
        insertError
      ) {
        console.error(
          "EDIT PROOF DB ERROR:",
          insertError
        );

        /*
          DB insert fail thì xoá
          file edit vừa upload.
          FILE GỐC VẪN AN TOÀN.
        */

        await supabase.storage
          .from("proofs")
          .remove([
            newFilePath,
          ]);

        alert(
          "Không thể lưu hồ sơ chỉnh sửa."
        );

        return;
      }

      /*
        -----------------------------------------------------
        7. XOÁ REVIEW DATA
        -----------------------------------------------------
      */

      await deleteEditProofData(
        `${EDIT_REVIEW_PREFIX}${student.mssv}`
      );

      /*
        -----------------------------------------------------
        8. HOÀN TẤT
        -----------------------------------------------------
      */

      alert(
        `Đã gửi hồ sơ bổ sung minh chứng v${newVersion}*.`
      );

      router.replace(
        "/dashboard"
      );
    } catch (error) {
      console.error(
        "CONFIRM EDIT PROOF ERROR:",
        error
      );

      alert(
        "Có lỗi xảy ra khi xác nhận hồ sơ."
      );
    } finally {
      setSaving(false);
    }
  }

  /* =======================================================
     BACK
  ======================================================== */

  function goBack() {
    router.push(
      "/dashboard/editproof"
    );
  }

  /* =======================================================
     LOADING
  ======================================================= */

  if (
    loading
  ) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-gray-100">
        <p className="text-gray-500">
          Đang tải...
        </p>
      </main>
    );
  }

  /* =======================================================
     UI
  ======================================================= */

  return (
    <main className="min-h-screen bg-gray-100 px-4 py-8">
      <div className="mx-auto max-w-4xl">

        {/* HEADER */}

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Xem xét minh chứng bổ sung
          </h1>

          <p className="mt-2 text-gray-600">
            Vui lòng kiểm tra lại toàn bộ
            minh chứng trước khi xác nhận.
          </p>
        </div>

        {/* STUDENT */}

        <div className="mb-6 rounded-2xl bg-white p-6 shadow-sm">
          <h2 className="text-xl font-semibold text-gray-900">
            Thông tin sinh viên
          </h2>

          <div className="mt-4 space-y-2 text-gray-700">
            <p>
              <span className="font-medium">
                Họ tên:
              </span>{" "}
              {student?.full_name}
            </p>

            <p>
              <span className="font-medium">
                MSSV:
              </span>{" "}
              {student?.mssv}
            </p>
          </div>
        </div>

        {/* PREVIEW */}

        <div className="space-y-6">

          {categories.map(
            (category) => {
              const items =
                proofData[
                  category.key
                ];

              if (
                items.length === 0
              ) {
                return null;
              }

              return (
                <section
                  key={
                    category.key
                  }
                  className="rounded-2xl bg-white p-6 shadow-sm"
                >
                  <h2 className="text-2xl font-semibold text-gray-900">
                    {
                      category.title
                    }
                  </h2>

                  <div className="mt-6 space-y-5">

                    {items.map(
                      (
                        item,
                        index
                      ) => (
                        <div
                          key={
                            item.id
                          }
                          className="rounded-xl border border-gray-200 bg-gray-50 p-5"
                        >
                          <p className="font-medium text-gray-800">
                            Minh chứng{" "}
                            {index +
                              1}
                          </p>

                          {item.fileName && (
                            <p className="mt-2 text-sm text-gray-500">
                              {
                                item.fileName
                              }
                            </p>
                          )}

                          {item.image && (
                            <div className="mt-4 overflow-hidden rounded-lg border border-gray-200 bg-white p-2">
                              <img
                                src={
                                  item.image
                                }
                                alt="Minh chứng"
                                className="max-h-96 w-full object-contain"
                              />
                            </div>
                          )}

                          {item.description && (
                            <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4">
                              <p className="text-sm font-medium text-gray-700">
                                Mô tả
                              </p>

                              <p className="mt-2 whitespace-pre-wrap text-sm text-gray-600">
                                {
                                  item.description
                                }
                              </p>
                            </div>
                          )}
                        </div>
                      )
                    )}

                  </div>
                </section>
              );
            }
          )}

        </div>

        {/* BUTTONS */}

        <div className="mt-8 flex items-center justify-between">

          <button
            type="button"
            onClick={
              goBack
            }
            disabled={saving}
            className="cursor-pointer rounded-lg border border-gray-300 bg-white px-6 py-3 font-medium text-gray-700 transition hover:bg-gray-50 disabled:opacity-50"
          >
            ← Chỉnh sửa lại
          </button>

          <button
            type="button"
            onClick={
              confirmEdit
            }
            disabled={saving}
            className="cursor-pointer rounded-lg bg-green-600 px-6 py-3 font-medium text-white transition hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {saving
              ? "Đang xác nhận..."
              : "Xác nhận"}
          </button>

        </div>

      </div>
    </main>
  );
}